﻿using ClassLibrary1;
using System;
using System.Collections.Generic;
using System.Diagnostics;

public class TestCollections
{
    static LinkedList<LorryCar> collection1 = new LinkedList<LorryCar>(); //Первая коллекция
    static LinkedList<string> collection2 = new LinkedList<string>(); //Вторая коллекция
    static SortedDictionary<Car, LorryCar> collection3 = new SortedDictionary<Car, LorryCar>(); //Третья коллекция
    static SortedDictionary<string, LorryCar> collection4 = new SortedDictionary<string, LorryCar>(); //Четвёртая коллекция
    static Stopwatch watch = Stopwatch.StartNew(); //Часы для подсчёта времени
    public TestCollections() //Конструктор для заполнения всех коллекций
    {
        for (int i = 0; i < 1000; i++)
        {
            LorryCar lorry =  new LorryCar();
            lorry.RandomInit();
            lorry = (LorryCar)lorry.Clone();
            collection1.AddLast(lorry);
            lorry = (LorryCar)lorry.Clone();
            collection2.AddLast(lorry.ToString());
            lorry = (LorryCar)lorry.Clone();
            collection3.Add(lorry.GetBase, lorry);
            lorry = (LorryCar)lorry.Clone();
            collection4.Add(lorry.GetBase.ToString(), lorry);
        }
    }

    public void SearchAll(int typeSearch, int count)
    {
        long sum; //Для записи суммы тиков

        List<LorryCar> lorriesLorryCar = new List<LorryCar>(); //Лист для записи грузовиков для поиска в коллекциях с номерами 1, 3, 4
        List<Car> lorriesCar = new List<Car>(); //Лист для записи машин для поиска в коллекции 3
        List<string> lorriesString = new List<string>(); //Лист для записи строк для поиска в коллекциях 2, 4

        List<long> times = new List<long>(); //Лист для записи времени для какждого элемента поиска
        List<bool> carIsFoundList = new List<bool>(); //Лист для записи флага: нашли элемент или нет
        bool carIsFound = false; //Сам флаг

        if (typeSearch == 1) //Поиск в LinkedList<LorryCar>
        {
            LorryCar carFirst = (LorryCar)collection1.First().Clone(); //Первый элемент
            LorryCar carMiddle = (LorryCar)collection1.ElementAt(500).Clone(); //Средний элемент
            LorryCar carLast = (LorryCar)collection1.Last().Clone(); //Последний элемент
            LorryCar carNonExistent = new LorryCar("НЕСУЩЕСТВУЮЩИЙ_ЭЛЕМЕНТ", 1971, "Orange", 29121623, 7, 999, 204); //Несуществующий элемент
            lorriesLorryCar.Add(carFirst); //Добавляем в лист
            lorriesLorryCar.Add(carMiddle);
            lorriesLorryCar.Add(carLast);
            lorriesLorryCar.Add(carNonExistent);
            foreach (LorryCar lorry in lorriesLorryCar) //Перебираем элементы в листе
            {
                sum = 0; //Для какждого элемента своя сумма
                for (int i = 0; i < count; i++) //count раз повторяем замер времени
                {
                    watch.Restart(); //Включили счётчик
                    carIsFound = collection1.Contains(lorry); //Ищем элемент
                    watch.Stop(); //Выключили счётчик
                    sum += watch.ElapsedTicks; //Прибавили время к сумме
                }
                carIsFoundList.Add(carIsFound); //Записали: нашли элемент или нет
                times.Add(sum / count); //Записали среднее время
            }
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Поиск в LinkedList<LorryCar>");
            Console.ResetColor();
        }
        //Далее всё аналогично и имеет место определённое повторение, но сократить код ещё больше не удалось
        else if (typeSearch == 2)
        {
            string carFirst = (string)collection2.First().Clone();
            string carMiddle = (string)collection2.ElementAt(500).Clone();
            string carLast = (string)collection2.Last().Clone();
            string carNonExistent = new LorryCar("НЕСУЩЕСТВУЮЩИЙ_ЭЛЕМЕНТ", 1971, "Orange", 29121623, 7, 999, 204).ToString();
            lorriesString.Add(carFirst);
            lorriesString.Add(carMiddle);
            lorriesString.Add(carLast);
            lorriesString.Add(carNonExistent);
            foreach (string lorry in lorriesString)
            {
                sum = 0;
                for (int i = 0; i < count; i++)
                {
                    watch.Restart();
                    carIsFound = collection2.Contains(lorry);
                    watch.Stop();
                    sum += watch.ElapsedTicks;
                }
                carIsFoundList.Add(carIsFound);
                times.Add(sum / count);
            }
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Поиск в LinkedList<string>");
            Console.ResetColor();
        }

        else if (typeSearch == 3)
        {
            Car carFirst = (Car)collection3.First().Key.Clone();
            Car carMiddle = (Car)collection3.ElementAt(500).Key.Clone();
            Car carLast = (Car)collection3.Last().Key.Clone();
            Car carNonExistent = new LorryCar("НЕСУЩЕСТВУЮЩИЙ_ЭЛЕМЕНТ", 1971, "Orange", 29121623, 7, 999, 204);
            lorriesCar.Add(carFirst);
            lorriesCar.Add(carMiddle);
            lorriesCar.Add(carLast);
            lorriesCar.Add(carNonExistent);
            foreach (Car lorry in lorriesCar)
            {
                sum = 0;
                for (int i = 0; i < count; i++)
                {
                    watch.Restart();
                    carIsFound = collection3.ContainsKey(lorry);
                    watch.Stop();
                    sum += watch.ElapsedTicks;
                }
                carIsFoundList.Add(carIsFound);
                times.Add(sum / count);
            }
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Поиск в SortedDictionary<Car, LorryCar> по ключу");
            Console.ResetColor();
        }

        else if (typeSearch == 4)
        {
            LorryCar carFirst = (LorryCar)collection3.First().Value.Clone();
            LorryCar carMiddle = (LorryCar)collection3.ElementAt(500).Value.Clone();
            LorryCar carLast = (LorryCar)collection3.Last().Value.Clone();
            LorryCar carNonExistent = new LorryCar("НЕСУЩЕСТВУЮЩИЙ_ЭЛЕМЕНТ", 1971, "Orange", 29121623, 7, 999, 204);
            lorriesLorryCar.Add(carFirst);
            lorriesLorryCar.Add(carMiddle);
            lorriesLorryCar.Add(carLast);
            lorriesLorryCar.Add(carNonExistent);
            foreach (LorryCar lorry in lorriesLorryCar)
            {
                sum = 0;
                for (int i = 0; i < count; i++)
                {
                    watch.Restart();
                    carIsFound = collection3.ContainsValue(lorry);
                    watch.Stop();
                    sum += watch.ElapsedTicks;
                }
                carIsFoundList.Add(carIsFound);
                times.Add(sum / count);
            }
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Поиск в SortedDictionary<Car, LorryCar> по значению");
            Console.ResetColor();
        }

        else if (typeSearch == 5)
        {
            string carFirst = (string)collection4.First().Key.Clone();
            string carMiddle = (string)collection4.ElementAt(500).Key.Clone();
            string carLast = (string)collection4.Last().Key.Clone();
            string carNonExistent = new LorryCar("НЕСУЩЕСТВУЮЩИЙ_ЭЛЕМЕНТ", 1971, "Orange", 29121623, 7, 999, 204).ToString();
            lorriesString.Add(carFirst);
            lorriesString.Add(carMiddle);
            lorriesString.Add(carLast);
            lorriesString.Add(carNonExistent);
            foreach (string lorry in lorriesString)
            {
                sum = 0;
                for (int i = 0; i < count; i++)
                {
                    watch.Restart();
                    carIsFound = collection4.ContainsKey(lorry);
                    watch.Stop();
                    sum += watch.ElapsedTicks;
                }
                carIsFoundList.Add(carIsFound);
                times.Add(sum / count);
            }
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Поиск в SortedDictionary<string, LorryCar> по ключу");
            Console.ResetColor();
        }

        else if (typeSearch == 6)
        {
            LorryCar carFirst = (LorryCar)collection4.First().Value.Clone();
            LorryCar carMiddle = (LorryCar)collection4.ElementAt(500).Value.Clone();
            LorryCar carLast = (LorryCar)collection4.Last().Value.Clone();
            LorryCar carNonExistent = new LorryCar("НЕСУЩЕСТВУЮЩИЙ_ЭЛЕМЕНТ", 1971, "Orange", 29121623, 7, 999, 204);
            lorriesLorryCar.Add(carFirst);
            lorriesLorryCar.Add(carMiddle);
            lorriesLorryCar.Add(carLast);
            lorriesLorryCar.Add(carNonExistent);
            foreach (LorryCar lorry in lorriesLorryCar)
            {
                sum = 0;
                for (int i = 0; i < count; i++)
                {
                    watch.Restart();
                    carIsFound = collection4.ContainsValue(lorry);
                    watch.Stop();
                    sum += watch.ElapsedTicks;
                }
                carIsFoundList.Add(carIsFound);
                times.Add(sum / count);
            }
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Поиск в SortedDictionary<string, LorryCar> по значению");
            Console.ResetColor();
        }


        for (int i = 0; i < 4; i++) //Перебираем индексы от 0 до 3. Эти индексы будут соответсовать элементам сразу в двух листах: в carIsFoundList, и в times.
        {
            if (i == 0)
            {
                Console.Write("Первый элемент: ");
            }
            else if (i == 1)
            {
                Console.Write("Средний элемент: ");
            }
            else if (i == 2)
            {
                Console.Write("Последний элемент: ");
            }
            else if (i == 3)
            {
                Console.Write("Несуществующий элемент: ");
            }

            if (carIsFoundList[i])
            {
                Console.WriteLine($"найден в среднем за {times[i]}");
            }
            else
            {
                Console.WriteLine($"не найден в среднем за {times[i]}");
            }
        }
    }

    public void SearchAllLaunch(int count) //Метод для того чтобы запустить все поиски
    {
        SearchAll(1, count);
        Console.WriteLine();
        SearchAll(2, count);
        Console.WriteLine();
        SearchAll(3, count);
        Console.WriteLine();
        SearchAll(4, count);
        Console.WriteLine();
        SearchAll(5, count);
        Console.WriteLine();
        SearchAll(6, count);
        Console.WriteLine();
    }
}